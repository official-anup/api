// alert("hello")
document.getElementById("btn").addEventListener("click",makerequest);



///////////////////////////////////////////////////
//catching error and showing data:
// function makerequest()
// {
//     console.log("button  is clicked.")
//     fetch("data.txt").then((res)=>{
    
//         //catching error
//         if(!res.ok)
//         {
//             throw Error(res.statusText)
//         }

//         console.log(res)
//         return res.text()

//     }).then((data)=>{
//        //showing data in browser
//        document.getElementById("divdata").innerHTML=data

//         console.log(data)

//     }).catch((error)=>{
//         console.log(error)
//     })
// }

/////////////// async and await ////////////////////////////////////////////
// people are using this
//  async function makerequest()
// {
//     console.log("button  is clicked.")
//     const res=await fetch("data.txt")
//     console.log(res)
//     const data=await res.text()
//     console.log(data)

////////////////////////////////////
//     document.getElementById("data").innerHTML=result.map((user)=>
//     `
//     <tr>
//       <td>${user.title}</td>
//       <td>${user.price}</td>
//       <td>${user.description}</td>
//       <td><img src="${user.image}"/></td>

//     </tr>
//     `
//   ).join("") 
// }

/////////////json---- async,await and error handling /////////////////////////////////

//catching error and showing data:
// function makerequest()
// {
//     console.log("button  is clicked.")
//     fetch("data.json").then((res)=>{
    
//         //catching error
//         if(!res.ok)
//         {
//             throw Error(res.statusText)
//         }

//         console.log("Res",res)
//         const dt=res.json()
//         console.log("Dt",dt)
//         return dt

//     }).then((data)=>{
//        //showing data in browser
//        document.getElementById("divdata1").innerHTML=data.name
//        document.getElementById("divdata2").innerHTML=data.age
//        document.getElementById("divdata3").innerHTML=data.city

//        document.getElementById("divdata4").innerHTML=data.name
//        document.getElementById("divdata5").innerHTML=data.age
//        document.getElementById("divdata6").innerHTML=data.city
//        document.getElementById("ip").innerHTML=data.city

//         console.log("Data",data)
//         console.log(data.name)
//         console.log(data.age)
//         console.log(data.city)


//     }).catch((error)=>{
//         console.log(error)
//     })
// }


///////////////// async and await  and erro handling //////////////////////////////////
async function makerequest()
{
try{
    console.log("button  is clicked.")
    const res=await fetch("data.json")
    console.log(res)
   if(!res.ok)
   {
    throw Error(res.statusText)
   }

    const data=await res.json()
    console.log(data)
    document.getElementById("divdata1").innerHTML=data.name
    document.getElementById("divdata2").innerHTML=data.age
    document.getElementById("divdata3").innerHTML=data.city

   }

   catch (err)
   {
     console.log(err)    
    document.getElementById("divdata1").innerHTML=err
    document.getElementById("divdata2").innerHTML=err
    document.getElementById("divdata3").innerHTML=err


   }
}
