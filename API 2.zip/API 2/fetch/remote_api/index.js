// alert("hello")
document.getElementById("btn").addEventListener("click",makerequest);


//single-multiple api in browser
// function makerequest()
// {
//     // fetch("https://jsonplaceholder.typicode.com/posts/1")
//     fetch("https://jsonplaceholder.typicode.com/posts")

//     .then((res)=>{
//      if(!res.ok)
//      {
//         throw Error(res.statusText)
//      }

//         console.log(res)
//         return res.json()
//     }).then((res)=>{
//         console.log(res)
 
//         //for single data
//         // document.getElementById("div1").innerHTML=res.id
//         // document.getElementById("div2").innerHTML=res.title
//         // document.getElementById("div3").innerHTML=res.body

//         //for multiple data
//     let alldata=document.getElementById("div")

//         res.forEach(element =>
//         {
//             console.log("ID :",element.id)
//             console.log("TITLE :",element.title)
//             console.log("BODY :",element.body)
        
//             alldata.innerHTML+=`
//                ID :<div style="color:brown">${element.id}</div>
//                TITLE :<div style="color:brown">${element.title}</div>
//                BODY :<div style="color:brown">${element.body}</div>
//                <hr>

//             `
           
//         })

//     }).catch((err)=>
//     {
//         console.log(err)

//         // for single data
//         // document.getElementById("div1").innerHTML=err
//         // document.getElementById("div2").innerHTML=err
//         // document.getElementById("div3").innerHTML=err

//     })
// 

//////////////// async await single data api in browser //////////////////////////////////////////

// async function makerequest()
// {
//     try
//     {
//      console.log("button clicked")
//        const get= await fetch("https://jsonplaceholder.typicode.com/posts/1")

//       if(!get.ok)
//       {
//         throw Error(get.statusText)
//       }
//       const data=await get.json()
//       console.log(data)
//       document.getElementById("div1").innerHTML=data.id
//       document.getElementById("div2").innerHTML=data.title
//       document.getElementById("div3").innerHTML=data.body
//     }
//     catch(err)
//     {
//         console.log(err)
//         document.getElementById("div1").innerHTML=err
//         document.getElementById("div2").innerHTML=err
//         document.getElementById("div3").innerHTML=err
//     }  
// }

////////////////// async await multiple data api in browser /////////////////////////////////////////

async function makerequest()
{
    try{
        console.log("button is clicked")
        const res=await fetch("https://jsonplaceholder.typicode.com/posts")

        if(!res.ok)
        {
            throw Error(res.statusText)
        }

        const data=await res.json()
        console.log(data)

        let alldata=document.getElementById("div")

         data.forEach(ele=>
            {
                alldata.innerHTML+=
                `
                ID :<div style="color:red">${ele.id}</div>
               TITLE : <div style="color:red">${ele.title}</div>
                BODY :<div style="color:red" >${ele.body}</div>

                `
            })

    }           
    catch(err)
    {
        console.log(err)
    }
}