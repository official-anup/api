// alert("hello")
document.getElementById("btn").addEventListener("click",makerequest);


// //Simple fetch
// function makerequest()
// {
//     console.log("button  is clicked.")
//     fetch("data.txt").then((res)=>{
//         console.log(res)
//         return res.text()
//     }).then((data)=>{
//         console.log(data)
//     })
// }

////////////////////////////////////////////////
// catching error
// function makerequest()
// {
//     console.log("button  is clicked.")
//     const promise= fetch("data.txt")
//     console.log(promise)
   
//     promise.then((res)=>{
//         // catching error
//        if(! res.ok)
//        {
//         throw Error(res.statusText)
//        }

//         console.log(res)
//         return res.text()
//     }).then((data)=>{
//         console.log(data)
     
//         //displaying data in browser
//         document.getElementById("divdata").innerHTML=data

//     }).catch((err)=>
//     {
//         console.log(err)
//     })
// }

///////////////////////////////////////////////////
//catching error and showing data:
// function makerequest()
// {
//     console.log("button  is clicked.")
//     fetch("data.txt").then((res)=>{
    
//         //catching error
//         if(!res.ok)
//         {
//             throw Error(res.statusText)
//         }

//         console.log(res)
//         return res.text()

//     }).then((data)=>{
//        //showing data in browser
//        document.getElementById("divdata").innerHTML=data

//         console.log(data)

//     }).catch((error)=>{
//         console.log(error)
//     })
// }

/////////////// async and await ////////////////////////////////////////////
// people are using this
//  async function makerequest()
// {
//     console.log("button  is clicked.")
//     const res=await fetch("data.txt")
//     console.log(res)
//     const data=await res.text()
//     console.log(data)

////////////////////////////////////
//     document.getElementById("data").innerHTML=result.map((user)=>
//     `
//     <tr>
//       <td>${user.title}</td>
//       <td>${user.price}</td>
//       <td>${user.description}</td>
//       <td><img src="${user.image}"/></td>

//     </tr>
//     `
//   ).join("") 
// }

///////////// async,await and error handling /////////////////////////////////
async function makerequest()
{
try{
    console.log("button  is clicked.")
    const res=await fetch("data1.txt")

    if(!res.ok)
    {
        throw Error(res.statusText)
    }
    console.log(res)
    const data=await res.text()
    console.log(data)

    document.getElementById("divdata").innerHTML=data
}
catch(error)
{
    console.log(error)
    document.getElementById("divdata").innerHTML=error
}
}


