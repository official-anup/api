// alert("hello")
document.getElementById("btn").addEventListener("click",makerequest);
// document.getElementById("btn").addEventListener("click",fun1);


// function makerequest()
// {
//     console.log("button is clicked")
//     fetch("https://reqres.in/api/users",
//{
//        

//method:"POST",

// body:'{"name":"Anup","job":"web dev"}',
//   headers:
//   {
//     "Content-type":"application/json ; charset=UTF-8"
//   }
//     }).then((res)=>{
//         if(!res.ok)
//         {
//             throw Error(res.statusText)
//         }
//         return res.json()
//     }).then((data)=>
//     {
//         console.log(data)
//     }).catch((err)=>
//     {
//         console.log(err)
//     })

// }

////////////// async and await ///////////////////////////////

// async function makerequest()
// {
//  try{
//    console.log("button is clicked")
//    const myInit=
//        {
//             method:"POST",
//             body:'{"name":"Anup","job":"web dev"}',
//               headers:
//               {
//                 "Content-type":"application/json ; charset=UTF-8"
//               }
//        }
   
//     const res= await fetch("https://reqres.in/api/users",myInit)

//     if(!res.ok)
//     {
//         throw Error(res.statusText)
//     }

//     const data=await res.json()
//     console.log(data)
//  }
//  catch(error)
//  {
//     console.log(error)
//  }
// }

////////////////////////////////////////////////

// function fun1()
// {


// let obj={
//     "userId": 5,
//     "id": 1,
//     "title": "anup alone",
//     "completed": true
//   }

// fetch("https://jsonplaceholder.typicode.com/todos",{

//   method:"POST",
//   body:JSON.stringify(obj),
//   headers:
//   {
//     "Content-type":"application/json ; charset=UTF-8"
//   }
// }).then((res)=>{
//     return res.json()
// }).then((data)=>{
//     console.log(data)
// })
// }

//////////////////// dynamic data with fetch and then//////////////////////////////
// function makerequest(e)
// {
//     e.preventDefault()
//     let name=document.getElementById("name").value
//     let job=document.getElementById("job").value
//     console.log("button is clicked")
//     let myInit={
        
//             method:"POST",
//             body:JSON.stringify({name:name,job:job}),
//               headers:
//               {
//                 "Content-type":"application/json ; charset=UTF-8"
//               }
//       }

//     console.log(myInit.body)
//     fetch("https://reqres.in/api/users",myInit).then((res)=>{
//         if(!res.ok)
//         {
//             throw Error(res.statusText)
//         }
//         return res.json()
//     }).then((data)=>
//     {
//         console.log(data)
//     }).catch((err)=>
//     {
//         console.log(err)
//     })

// }

////////////// dynamic data with await and async ///////////////////////////////////////////////

// async function makerequest(e)
// {
//  e.preventDefault()
//  let name=document.getElementById("name").value
//  let job=document.getElementById("job").value

//  try{
//    console.log("button is clicked")
//    const myInit=
//        {
//             method:"POST",
//             body:JSON.stringify({name:name,job:job}),
//               headers:
//               {
//                 "Content-type":"application/json ; charset=UTF-8"
//               }
//        }
//    console.log(myInit.body)
//     const res= await fetch("https://reqres.in/api/users",myInit)

//     if(!res.ok)
//     {
//         throw Error(res.statusText)
//     }

//     const data=await res.json()
//     console.log(data)
//  }
//  catch(error)
//  {
//     console.log(error)
//  }
// }

//////////////////////// get sample///////////////////////////////////////////

async function makerequest(e)
{
 e.preventDefault()
 let name=document.getElementById("name").value
//  let job=document.getElementById("job").value

 try{
   console.log("button is clicked")
   const myInit=
       {
            method:"GET",
            body:JSON.stringify({name:name}),
              headers:
              {
                "Content-type":"application/json ; charset=UTF-8"
              }
       }
   console.log(myInit.body)
    const res= await fetch("https://reqres.in/api/users",myInit)

    if(!res.ok)
    {
        throw Error(res.statusText)
    }

    const data=await res.json()
    console.log(data)
 }
 catch(error)
 {
    console.log(error)
 }
}