// alert("hello") 
document.getElementById("get").addEventListener("click",getdata);
document.getElementById("post").addEventListener("click",postdata);
document.getElementById("put").addEventListener("click",putdata);
document.getElementById("patch").addEventListener("click",getdata);
document.getElementById("delete").addEventListener("click",getdata);


async function getdata()
{
 
    try
    {
    let result=await fetch("https://jsonplaceholder.typicode.com/posts")

    if(!result.ok)
    {
        throw Error(result.statusText)
    }
     result=await result.json()
     console.log(result)

     document.getElementById("data").innerHTML=result.map((user)=>
     `
       <tr>
         <td>${user.id}</td>
         <td>${user.title}</td>
         <td>${user.body}</td>
       </tr>
       `
     ).join("") 
         
    }

    catch(err)
    {
        console.log(err)
    }
}


async function postdata(e)
{
  try
  {
    e.preventDefault()
   const newPost=
   {
    userId:1,
    title:"This is new title",
    body:"This is new body"
   }

    const myInit=
    {
         method:"POST",
         body:JSON.stringify(newPost),
           headers:
           {
             "Content-type":"application/json ; charset=UTF-8"
           }
    }
console.log(myInit.body)

   const result= await fetch("https://jsonplaceholder.typicode.com/posts",myInit)
   console.log(result)

   if(!result.ok)
   {
       throw Error(result.statusText)
   }
     const data=await result.json()
    console.log(data)

   
     
  }
  catch(err)
  {
   console.log(err)
  }
}


async function putdata(myInit,id)
{
  try
  {
    // e.preventDefault()
   const newPost=
   {id:1,
    userId:1,
    title:"This is updated title",
    body:"This is updated body"
   }

    const myInit=
    {
         method:"PUT",
         body:JSON.stringify(newPost),
           headers:
           {
             "Content-type":"application/json ; charset=UTF-8"
           }
    }
console.log("This is body",myInit.body)

   const result= await fetch("https://jsonplaceholder.typicode.com/posts/")
   console.log("this is result",result)

   if(!result.ok)
   {
       throw Error(result.statusText)
   }
     const data=await result.json()
    console.log("this is data",data)

   
     
  }
  catch(err)
  {
   console.log(err)
  }
}