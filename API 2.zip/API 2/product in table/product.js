fetch("https://fakestoreapi.com/products").then((data)=> // original data is in json format
// when we fetch something then we get promise that will resolve into another one. 
{
    console.log(data)
    return data.json() //this will convert json data into object
}).then((objectdata)=>
{
    console.log(objectdata[0].title)
    let tabledata=""
    objectdata.map((values)=>
    {
        tabledata+=`
        <tr>
            <td>${values.title}</td>
            <td>${values.description}</td>
            <td>${values.price}</td>
            <td><img src="${values.image}" /></td>
          </tr>
        `
    })
    document.getElementById("table_body").innerHTML=tabledata
})